

Single PWM made from DSP48E1.

Simulated for Artix-7, but not tested in hardware.



--------------------------------------------------
Folders in the zip file:

doc:  short word document that describes the macro.

prj: Vivado project with source files and tesstbench.

sim:  VHDL testbench for simulation.

src: VHDL source files of PWM.

---------------------------------------------------


